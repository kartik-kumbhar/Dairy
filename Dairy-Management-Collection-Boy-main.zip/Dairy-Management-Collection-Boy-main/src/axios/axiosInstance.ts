import axios from "axios";

export const api = axios.create({
  // import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api"
  baseURL:"http://localhost:5000/api",
  withCredentials: true,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});
